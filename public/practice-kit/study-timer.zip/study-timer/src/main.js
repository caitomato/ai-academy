const button = document.querySelector("button");
button.addEventListener("click", () => {
  button.textContent = "计时中";
});